import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clienti-filter',
  templateUrl: './clienti-filter.component.html',
  styleUrls: ['./clienti-filter.component.scss']
})
export class ClientiFilterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
