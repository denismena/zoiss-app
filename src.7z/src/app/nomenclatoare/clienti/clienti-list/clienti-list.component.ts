import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clienti-list',
  templateUrl: './clienti-list.component.html',
  styleUrls: ['./clienti-list.component.scss']
})
export class ClientiListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
