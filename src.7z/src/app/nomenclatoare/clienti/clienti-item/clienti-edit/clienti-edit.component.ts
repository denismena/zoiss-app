import { Component, OnInit } from '@angular/core';
import { clientiDTO } from '../clienti.model';

@Component({
  selector: 'app-clienti-edit',
  templateUrl: './clienti-edit.component.html',
  styleUrls: ['./clienti-edit.component.scss']
})
export class ClientiEditComponent implements OnInit {

  constructor() { }

  model:clientiDTO = { nume:'ion', pf_pj: 1, cui_cnp: '21323432', registru_comertului:'dsadsa', active: true}
  ngOnInit(): void {
  }
  saveChanges(clientiDTO: clientiDTO){

  }
}
