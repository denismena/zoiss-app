import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { clientiDTO } from './clienti.model';

@Component({
  selector: 'app-clienti-item',
  templateUrl: './clienti-item.component.html',
  styleUrls: ['./clienti-item.component.scss']
})
export class ClientiItemComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute, private formBuilder:FormBuilder) { }
  
  @Input()
  model:clientiDTO | undefined;
  public form!: FormGroup;
  
  @Output()
  onSaveChanges: EventEmitter<clientiDTO> = new EventEmitter<clientiDTO>();
  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params=>{
      //alert(params.id);
    });
    this.form = this.formBuilder.group({
      nume:['', {validators:[Validators.required]}],
      pf_pj:0,
      cui_cnp:'',
      registru_comertului:'',
      active: 1
    });
    if(this.model !== undefined)
    {
      this.form.patchValue(this.model);
    }    
  }
  save(){
    //this.router.navigate(['/clienti'])
    this.onSaveChanges.emit(this.form.value);
  }
}
