export interface clientiDTO{
    nume: string;
    pf_pj: number;
    cui_cnp: string;
    registru_comertului: string;
    active: boolean;
}