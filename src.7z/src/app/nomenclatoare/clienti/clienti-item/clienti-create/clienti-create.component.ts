import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { clientiDTO } from '../clienti.model';

@Component({
  selector: 'app-clienti-create',
  templateUrl: './clienti-create.component.html',
  styleUrls: ['./clienti-create.component.scss']
})
export class ClientiCreateComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  saveChanges(clientiDTO:clientiDTO){
    console.log(clientiDTO);
    this.router.navigate(['/clienti'])
  }
}
