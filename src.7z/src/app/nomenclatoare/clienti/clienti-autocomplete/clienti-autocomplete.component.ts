import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { clientiDTO } from '../clienti-item/clienti.model';

@Component({
  selector: 'app-clienti-autocomplete',
  templateUrl: './clienti-autocomplete.component.html',
  styleUrls: ['./clienti-autocomplete.component.scss']
})
export class ClientiAutocompleteComponent implements OnInit {

  constructor() { 
    this.selectedClient = new Observable<clientiDTO[]>();
    this.selectedClient = this.clientCtrl.valueChanges
      .pipe(
        startWith(''),
        map(c => c ? this._filterStates(c) : this.clienti.slice())
      );
  }
  clientCtrl: FormControl = new FormControl();
  selectedClient: any;
  @Output()
  onOptionSelected: EventEmitter<string> = new EventEmitter<string>();

  clienti: clientiDTO[] = [
    {nume: 'client 1', pf_pj: 1, cui_cnp: '2123se32432', registru_comertului: 'dsadsa', active: true },
    {nume: 'client 2', pf_pj: 0, cui_cnp: 'fdsfds', registru_comertului: 'cvxvbvbc', active: false },
    {nume: 'client 3', pf_pj: 1, cui_cnp: '54grtrerte', registru_comertului: 'dsadsa', active: true }
  ]

  ngOnInit(): void {
  }
  optionSelected(event: MatAutocompleteSelectedEvent){
    //console.log(event.option.value);
    //this.selectedProdus.push(event.option.value);
    this.onOptionSelected.emit(event.option.value);
    //this.produsCtrl.patchValue('');
  }

  private _filterStates(value: string): clientiDTO[] {
    const filterValue = value.toLowerCase();
    return this.clienti.filter(p => p.nume.toLowerCase().includes(filterValue));
  }

}
