import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { produseDTO } from '../produse-item/produse.model';

@Component({
  selector: 'app-produse-autocomplete',
  templateUrl: './produse-autocomplete.component.html',
  styleUrls: ['./produse-autocomplete.component.scss']
})
export class ProduseAutocompleteComponent implements OnInit {

  constructor() { 
    this.selectedProdus = new Observable<produseDTO[]>();
    this.selectedProdus = this.produsCtrl.valueChanges
      .pipe(
        startWith(''),
        map(state => state ? this._filterStates(state) : this.produse.slice())
      );
  }
  produsCtrl: FormControl = new FormControl();
  selectedProdus: any;
  @Output()
  onOptionSelected: EventEmitter<string> = new EventEmitter<string>();

  produse: produseDTO[] = [];

  ngOnInit(): void {
    // this.control.valueChanges.subscribe(value=>{
    //   this.produse = this.originalProduse;
    //   this.produse = this.produse.filter(produs => produs.nume.indexOf(value) !== -1)
    // })
  }

  optionSelected(event: MatAutocompleteSelectedEvent){
    //console.log(event.option.value);
    //this.selectedProdus.push(event.option.value);
    this.onOptionSelected.emit(event.option.value);
    //this.produsCtrl.patchValue('');
  }

  private _filterStates(value: string): produseDTO[] {
    const filterValue = value.toLowerCase();
    return this.produse.filter(p => p.Nume.toLowerCase().includes(filterValue));
  }

}
