import { Component, OnInit } from '@angular/core';
import { produseDTO } from '../produse-item/produse.model';
import { ProduseService } from '../produse.service';

@Component({
  selector: 'app-produse-list',
  templateUrl: './produse-list.component.html',
  styleUrls: ['./produse-list.component.scss']
})
export class ProduseListComponent implements OnInit {

  produse!: produseDTO[];
  constructor(private produseService: ProduseService) {  
    this.produse = [];
  }
  // produse: produseAPI_DTO[] =[
  //   { id: 1, cod:'2ssda', nume:'ion1', um: 'kg', per_cutie: 1.2 , pret:12.34, cod_vamal:'bds', greutate_per_um: 2.34, poza:'https://zoiss.ro/wp-content/uploads/2021/07/zoiss-2f.jpg', active: true},
  //   { id: 2, cod:'654fdf', nume:'ion2', um: 'buc', per_cutie: 1.2 , pret:0.34, cod_vamal:'ssdsadsa', greutate_per_um: 23.34, poza:'https://zoiss.ro/wp-content/uploads/2021/07/zoiss-24.jpg', active: true},
  //   { id: 3, cod:'54fhhh', nume:'rr', um: 'kg', per_cutie: 1.2 , pret:12.34, cod_vamal:'hjiii', greutate_per_um: 21.34, poza:'https://zoiss.ro/wp-content/uploads/2021/05/zoiss-3.jpg', active: true}    
  // ]; 

  columnsToDislay= ['Cod', 'Nume', 'UM', 'poza'];

  ngOnInit(): void {
    this.produseService.getAll().subscribe(produse=>{
      this.produse = produse;
      console.log(this.produse);
    });
    //console.log(this.produse);
  }

  edit(produs: produseDTO){

  }
  remove(produs: produseDTO){

  }

}
