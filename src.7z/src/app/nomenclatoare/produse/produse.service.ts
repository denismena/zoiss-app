import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { produseCreationDTO, produseDTO } from './produse-item/produse.model';

@Injectable({
  providedIn: 'root'
})
export class ProduseService {

  constructor(private http: HttpClient) { }
  private apiUrl = environment.apiUrl + '/produse';

  getAll(): Observable<produseDTO[]>{
    return this.http.get<produseDTO[]>(this.apiUrl);
  }

  create(produse: produseCreationDTO){
    return this.http.post(this.apiUrl, produse);
  }
}
