export interface produseDTO{
    Id: number;
    Nume: string;
    Cod: string;
    Um: string;
    PerCutie: number;
    Pret: number;
    GreutatePerUm: number;
    CodVamal: string;
    Poza: string;
    Active: boolean;
}

export interface produseCreationDTO{    
    Nume: string;
    Cod: string;
    Um: string;
    PerCutie: number;
    Pret: number;
    GreutatePerUm: number;
    CodVamal: string;
    Active: boolean;
}