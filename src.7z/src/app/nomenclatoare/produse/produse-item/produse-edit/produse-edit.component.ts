import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { produseCreationDTO,produseDTO } from '../produse.model';

@Component({
  selector: 'app-produse-edit',
  templateUrl: './produse-edit.component.html',
  styleUrls: ['./produse-edit.component.scss']
})
export class ProduseEditComponent implements OnInit {

  constructor(private router:Router) { }

  model!:produseDTO;
  ngOnInit(): void {
  }
  saveChanges(produseCreationDTO:produseCreationDTO){
    console.log(produseCreationDTO);
    this.router.navigate(['produse'])
  }

}
