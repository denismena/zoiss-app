import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-furnizori-list',
  templateUrl: './furnizori-list.component.html',
  styleUrls: ['./furnizori-list.component.scss']
})
export class FurnizoriListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
