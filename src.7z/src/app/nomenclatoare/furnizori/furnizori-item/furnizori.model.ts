export interface furnizoriDTO{
    nume: string;
    tara: string;
    adresa: string;
    telefon: string;
    email: string;
    active: boolean;
}