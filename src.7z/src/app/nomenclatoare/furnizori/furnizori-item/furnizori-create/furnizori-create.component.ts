import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { furnizoriDTO } from '../furnizori.model';

@Component({
  selector: 'app-furnizori-create',
  templateUrl: './furnizori-create.component.html',
  styleUrls: ['./furnizori-create.component.scss']
})
export class FurnizoriCreateComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  saveChanges(furnizoriDTO: furnizoriDTO){
    console.log(furnizoriDTO);
    this.router.navigate(['/furnizori'])
  }

}
