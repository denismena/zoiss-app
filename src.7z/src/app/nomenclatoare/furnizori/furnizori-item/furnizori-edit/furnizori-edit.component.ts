import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { furnizoriDTO } from '../furnizori.model';

@Component({
  selector: 'app-furnizori-edit',
  templateUrl: './furnizori-edit.component.html',
  styleUrls: ['./furnizori-edit.component.scss']
})
export class FurnizoriEditComponent implements OnInit {

  constructor(private router:Router) { }

  model:furnizoriDTO = { nume:'furnizor ion', tara:'Romania', adresa:'Soveja 62, Constanta', telefon: '9832/332344', email: 'sad@dddsf.ro', active: true}
  ngOnInit(): void {
  }
  saveChanges(furnizoriDTO:furnizoriDTO){
    console.log(furnizoriDTO);
    this.router.navigate(['/furnizori'])
  }

}
