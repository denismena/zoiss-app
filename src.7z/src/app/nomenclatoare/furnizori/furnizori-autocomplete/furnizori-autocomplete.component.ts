import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { furnizoriDTO } from '../furnizori-item/furnizori.model';

@Component({
  selector: 'app-furnizori-autocomplete',
  templateUrl: './furnizori-autocomplete.component.html',
  styleUrls: ['./furnizori-autocomplete.component.scss']
})
export class FurnizoriAutocompleteComponent implements OnInit {

  constructor() { 
    this.selectedFurnizor = new Observable<furnizoriDTO[]>();
    this.selectedFurnizor = this.furnizorCtrl.valueChanges
      .pipe(
        startWith(''),
        map(c => c ? this._filterStates(c) : this.furnizori.slice())
      );
  }

  furnizorCtrl: FormControl = new FormControl();
  selectedFurnizor: any;
  @Output()
  onOptionSelected: EventEmitter<string> = new EventEmitter<string>();

  furnizori: furnizoriDTO[] = [
    { nume:'f1', tara: 'romania', adresa: 'bucuresti strada 1', telefon: '9082309432', email: 'f1@wsjksasjd.ro', active: true},
    { nume:'f2', tara: 'romania', adresa: ' strada 2', telefon: '9082309432', email: 'f1@wsjksasjd.ro', active: true},
    { nume:'f3', tara: 'spania', adresa: 'bucuresti strada 4', telefon: '9082309432', email: 'f1@wsjksasjd.ro', active: true},
    { nume:'f4', tara: 'italia', adresa: ' strada 3', telefon: '9082309432', email: 'f1@wsjksasjd.ro', active: true}
  ]
  ngOnInit(): void {
  }

  optionSelected(event: MatAutocompleteSelectedEvent){
    //console.log(event.option.value);
    //this.selectedProdus.push(event.option.value);
    this.onOptionSelected.emit(event.option.value);
    //this.produsCtrl.patchValue('');
  }

  private _filterStates(value: string): furnizoriDTO[] {
    const filterValue = value.toLowerCase();
    return this.furnizori.filter(p => p.nume.toLowerCase().includes(filterValue));
  }

}
