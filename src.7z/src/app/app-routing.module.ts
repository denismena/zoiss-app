import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProduseListComponent } from './nomenclatoare/produse/produse-list/produse-list.component';
import { ProduseCreateComponent } from './nomenclatoare/produse/produse-item/produse-create/produse-create.component'
import { ProduseEditComponent } from './nomenclatoare/produse/produse-item/produse-edit/produse-edit.component';
import { ClientiListComponent } from './nomenclatoare/clienti/clienti-list/clienti-list.component';
import { ClientiCreateComponent } from './nomenclatoare/clienti/clienti-item/clienti-create/clienti-create.component';
import { ClientiEditComponent } from './nomenclatoare/clienti/clienti-item/clienti-edit/clienti-edit.component';
import { ClientiFilterComponent } from './nomenclatoare/clienti/clienti-list/clienti-filter/clienti-filter.component';
import { FurnizoriListComponent} from './nomenclatoare/furnizori/furnizori-list/furnizori-list.component';
import { FurnizoriCreateComponent } from './nomenclatoare/furnizori/furnizori-item/furnizori-create/furnizori-create.component';
import { FurnizoriEditComponent } from './nomenclatoare/furnizori/furnizori-item/furnizori-edit/furnizori-edit.component';
import { OferteListComponent } from './oferte/oferte-list/oferte-list.component';
import { OferteFilterComponent } from './oferte/oferte-list/oferte-filter/oferte-filter.component';
import { OferteCreateComponent } from './oferte/oferte-item/oferte-create/oferte-create.component';
import { OferteEditComponent } from './oferte/oferte-item/oferte-edit/oferte-edit.component';

const routes: Routes = [
  {path:  "", pathMatch:  "full",redirectTo:  "home"},
  {path: "home", component: HomeComponent},

  {path: "produse", component: ProduseListComponent},
  {path: "produse/create", component: ProduseCreateComponent},
  {path: "produse/edit/:id", component: ProduseEditComponent},
  
  {path: "furnizori", component: FurnizoriListComponent},
  {path: "furnizori/create", component: FurnizoriCreateComponent},
  {path: "furnizori/edit/:id", component: FurnizoriEditComponent},

  {path: "clienti", component: ClientiListComponent} ,
  {path: "clienti/create", component: ClientiCreateComponent},
  {path: "clienti/edit/:id", component: ClientiEditComponent},
  {path: "clienti/filter", component: ClientiFilterComponent},

  {path: "oferte", component: OferteListComponent} ,
  {path: "oferte/create", component: OferteCreateComponent},
  {path: "oferte/edit/:id", component: OferteEditComponent},
  {path: "oferte/filter", component: OferteFilterComponent},

  {path: '**', redirectTo:''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
