import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oferte-list',
  templateUrl: './oferte-list.component.html',
  styleUrls: ['./oferte-list.component.scss']
})
export class OferteListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
