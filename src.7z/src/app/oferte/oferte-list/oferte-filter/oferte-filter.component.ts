import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oferte-filter',
  templateUrl: './oferte-filter.component.html',
  styleUrls: ['./oferte-filter.component.scss']
})
export class OferteFilterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
