import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { oferteDTO } from '../oferte.model';

@Component({
  selector: 'app-oferte-create',
  templateUrl: './oferte-create.component.html',
  styleUrls: ['./oferte-create.component.scss']
})
export class OferteCreateComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  saveChanges(oferteDTO:oferteDTO){
    console.log(oferteDTO);
    this.router.navigate(['/oferte'])
  }

}
