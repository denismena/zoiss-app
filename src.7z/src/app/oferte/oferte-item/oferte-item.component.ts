import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { oferteDTO } from './oferte.model';

@Component({
  selector: 'app-oferte-item',
  templateUrl: './oferte-item.component.html',
  styleUrls: ['./oferte-item.component.scss']
})
export class OferteItemComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute, private formBuilder:FormBuilder) { }
  @Input()
  model:oferteDTO | undefined;
  public form!: FormGroup;
  
  @Output()
  onSaveChanges: EventEmitter<oferteDTO> = new EventEmitter<oferteDTO>();

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params=>{
      //alert(params.id);
    });
    this.form = this.formBuilder.group({
      numar:[1, {validators:[Validators.required]}],
      data:[new Date(), {validators:[Validators.required]}],
      clientId:[null, {validators:[Validators.required]}],
      arhitectId: null,
      utilizatorId:[1, {validators:[Validators.required]}],
      avans: null,
      conditii_plata: '',
      termen_livrare: ''
    });
    if(this.model !== undefined)
    {
      this.form.patchValue(this.model);
    }    
  }
  save(){
    this.onSaveChanges.emit(this.form.value);
  }
  selectClient(clientNume: string){
    this.form.get('clientId')?.setValue(clientNume);
    console.log('clientNume: ', this.form.get('clientId')?.value);
  }

}
