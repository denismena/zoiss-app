export interface oferteDTO{
    numar: number;
    data: Date;
    clientId: number;
    arhitectId: number;
    utilizatorId: number;
    avans: number;
    conditii_plata: string;
    termen_livrare: string;
}