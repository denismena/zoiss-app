import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { oferteDTO } from '../oferte.model';

@Component({
  selector: 'app-oferte-edit',
  templateUrl: './oferte-edit.component.html',
  styleUrls: ['./oferte-edit.component.scss']
})
export class OferteEditComponent implements OnInit {

  constructor(private router:Router) { }
  
  model:oferteDTO = { numar: 1, data: new Date(), clientId: 1, arhitectId: 1, utilizatorId: 1, avans: 12, conditii_plata:'', termen_livrare: ''}
  ngOnInit(): void {
  }
  saveChanges(oferteDTO: oferteDTO){
    console.log(oferteDTO);
    this.router.navigate(['/oferte'])
  }

}
