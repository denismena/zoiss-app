import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { ProduseListComponent } from './nomenclatoare/produse/produse-list/produse-list.component';
import { ProduseItemComponent } from './nomenclatoare/produse/produse-item/produse-item.component';
import { ClientiListComponent } from './nomenclatoare/clienti/clienti-list/clienti-list.component';
import { ClientiItemComponent } from './nomenclatoare/clienti/clienti-item/clienti-item.component';
import { ClientiCreateComponent } from './nomenclatoare/clienti/clienti-item/clienti-create/clienti-create.component';
import { ClientiEditComponent } from './nomenclatoare/clienti/clienti-item/clienti-edit/clienti-edit.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { ClientiFilterComponent } from './nomenclatoare/clienti/clienti-list/clienti-filter/clienti-filter.component';
import { ProduseCreateComponent } from './nomenclatoare/produse/produse-item/produse-create/produse-create.component';
import { ProduseEditComponent } from './nomenclatoare/produse/produse-item/produse-edit/produse-edit.component';
import { FurnizoriListComponent } from './nomenclatoare/furnizori/furnizori-list/furnizori-list.component';
import { FurnizoriItemComponent } from './nomenclatoare/furnizori/furnizori-item/furnizori-item.component';
import { FurnizoriCreateComponent } from './nomenclatoare/furnizori/furnizori-item/furnizori-create/furnizori-create.component';
import { FurnizoriEditComponent } from './nomenclatoare/furnizori/furnizori-item/furnizori-edit/furnizori-edit.component';
import { OferteListComponent } from './oferte/oferte-list/oferte-list.component';
import { OferteFilterComponent } from './oferte/oferte-list/oferte-filter/oferte-filter.component';
import { OferteItemComponent } from './oferte/oferte-item/oferte-item.component';
import { OferteCreateComponent } from './oferte/oferte-item/oferte-create/oferte-create.component';
import { OferteEditComponent } from './oferte/oferte-item/oferte-edit/oferte-edit.component';
import { ProduseAutocompleteComponent } from './nomenclatoare/produse/produse-autocomplete/produse-autocomplete.component';
import { ClientiAutocompleteComponent } from './nomenclatoare/clienti/clienti-autocomplete/clienti-autocomplete.component';
import { FurnizoriAutocompleteComponent } from './nomenclatoare/furnizori/furnizori-autocomplete/furnizori-autocomplete.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProduseListComponent,
    ProduseItemComponent,
    ClientiListComponent,
    ClientiItemComponent,
    HeaderComponent,
    FooterComponent,
    ClientiCreateComponent,
    ClientiEditComponent,
    ClientiFilterComponent,
    ProduseCreateComponent,
    ProduseEditComponent,
    FurnizoriListComponent,
    FurnizoriItemComponent,
    FurnizoriCreateComponent,
    FurnizoriEditComponent,
    OferteListComponent,
    OferteFilterComponent,
    OferteItemComponent,
    OferteCreateComponent,
    OferteEditComponent,
    ProduseAutocompleteComponent,
    ClientiAutocompleteComponent,
    FurnizoriAutocompleteComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
